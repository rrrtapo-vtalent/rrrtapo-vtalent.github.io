# Jarvis kit — read me

This kit lets you build a personal assistant with memory, guided step by step by Claude.

**To start:** open claude.ai, start a new chat and drag in the file `steps/00-start-here.md`. From there Claude guides you, and at the end of each step it tells you which file to drag in next.

What's in here:

- `GUIDE.md` and `Guide - Build your own Jarvis.pdf`: the guide for you, to read or print, so you always know where you are.
- `steps/`: Claude's instructions, from `00` to `10`. You don't need to read them: drag them into the chat, one at a time.
- `template/`: the skeleton of your assistant's folder. At step 02 you copy its contents into a folder of your own.

You need a computer (Mac or Windows) and a paid Claude plan, Pro or above, for the Code tab of the desktop app.

Kit prepared by Mattia Porta. November 2026 edition.
