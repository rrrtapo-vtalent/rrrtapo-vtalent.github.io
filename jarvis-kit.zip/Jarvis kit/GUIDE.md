# Build your own Jarvis

A personal assistant that remembers you, your things and how you like to work. This guide takes you from start to finish even if you've never written a line of code: Claude does the technical work, you follow the steps and make the decisions.

## What you're about to build

On its own, Claude forgets everything at the end of each conversation. Your Jarvis doesn't, because it keeps its memory in a folder on your computer: plain text files it reads at the start of every session and updates as you work. Inside are its rules, your calendar, your ideas, the status of each project, a journal of what happens and a log of its mistakes.

At the end you'll have:

- an assistant with the name, language and tone you choose;
- a calendar and an "inbox" to unload everything on your mind;
- a folder for each project, always saying where you've got to and what the next step is;
- a private backup on GitHub with the history of every change;
- if you want, reminders on your phone and an automatic check every night.

## What you need

- A computer, Mac or Windows.
- A Claude account on a paid plan, Pro or above: your Jarvis lives in the Code tab of the Claude desktop app, included in paid plans. Current pricing is at claude.com/pricing. With the free plan you can do the first part of the guide, not the second.
- An hour or two for the build, then a week of daily use, even five minutes a day.

## How this kit works

- The `steps/` folder holds eleven numbered files, from `00` to `10`. Each one contains Claude's instructions for one step of the build. **You don't need to read them**: you drag them into the chat, one at a time, and Claude knows what to do. At the end of each step, Claude tells you which file comes next.
- The `template/` folder holds the skeleton of your assistant's folder, with the files ready to be personalised.
- There's also this guide, to read or print, so you always know where you are.

The build has two phases. In the **first**, you talk with Claude on the claude.ai website, which acts as your instructor. In the **second**, you talk with your new assistant, which finishes building itself together with you.

## Phase 1 — On claude.ai, with Claude as instructor

### Step 00. Start here

Open claude.ai, start a new chat and drag in `00-start-here.md`. Claude explains the path and asks you four questions: which computer you use, which plan you have, how comfortable you are with files and folders, what you want your assistant to do for you.

*At the end:* you know what you need, and Claude knows your situation.

### Step 01. How it works

Drag `01-how-it-works.md` into the same chat. Claude explains the six ideas everything rests on: why Claude doesn't remember, why the memory lives in text files, why rules are written once, why everything has one home, why the assistant must cite its sources and write down its mistakes, why every session has a beginning and an end.

*At the end:* you can explain in your own words why the files are needed.

### Step 02. Prepare the computer

Drag in `02-prepare-the-computer.md`. This step is hands-on, one thing at a time:

1. you activate the paid plan, if you don't have it;
2. you install the **Claude desktop app** from claude.com/download and sign in with your account;
3. you look at the app's **Code** tab: that's where your assistant will live;
4. you create a folder with its name, for example `Jarvis`, in Documents. Better not in a folder synced by OneDrive, iCloud or Dropbox;
5. you copy into it all the contents of the kit's `template` folder;
6. if you like, you install **Obsidian** (free) to read the files comfortably.

*At the end:* the folder contains `CLAUDE.md`, `Calendar.md`, `Inbox.md`, `Ideas.md`, `Profile.md`, `Mistakes log.md` and the folders `Journal`, `Files`, `Projects`.

### Step 03. Your tailored assistant

Drag in `03-your-tailored-assistant.md` **together with** the `CLAUDE.md` and `Profile.md` files from your folder. Claude interviews you: what to call the assistant, what it should call you, language, tone, who you are, which areas of your life it should look after, what it must never do, how you work best. Then it gives you back the two complete files: you open them, replace all the text, save.

*At the end:* `CLAUDE.md` has no placeholders left in double braces `{{ }}`.

### Step 04. First launch

Drag in `04-first-launch.md`. Open the desktop app, **Code** tab, choose to work locally and open your assistant's folder. Type "Hi". Then run five checks:

1. **it introduces itself** with the name you chose;
2. **it knows you**: asked "what do you know about me?", it answers with your profile;
3. **it doesn't make things up**: asked about something you've never told it, it answers "I don't know";
4. **it writes**: if you ask it to put something in your calendar, you find it in the file;
5. **it remembers**: close the session, open a new one, and it still knows what's in the calendar.

*At the end:* your assistant is alive. From here on you drag the files into its chat, not into claude.ai any more.

## Phase 2 — With your assistant

### Step 05. The first week

Drag `05-the-first-week.md` into your assistant's chat. It teaches you four habits, using them on real things: emptying your head into the inbox and sorting it; creating your first project with its status; closing the session; reopening it the next day without having to remember anything. Then for five to seven days you use it every day, even for a few minutes. Whenever something doesn't suit you, tell it: it suggests a new rule, and from then on the rule applies for good.

### Step 06. The backup

Drag in `06-the-backup.md`. The assistant helps you create a GitHub account (free) and a **private** repository, and connects the folder to it with Git. From then on every change has a history, you can always go back, and if the computer breaks the memory isn't lost. If you prefer buttons to commands, you can use GitHub Desktop.

*At the end:* on GitHub you see your files, marked **Private**.

### Step 07. The first review

After at least a week, drag in `07-the-first-review.md`. This is where the assistant really improves: you empty the inbox, look at what's overdue in the calendar and at stalled projects ("alive, dead or to be broken down?"), read the log of its mistakes and, for the ones that repeat, fix the rule that causes them. From then on, it suggests the review to you every week.

*At the end:* the basic build is finished.

## Optional chapters

Whenever you like, in any order.

### Step 08. Phone reminders

With the free **ntfy** app and a small script the computer runs on its own, appointments with a time reach you as a notification the day before and an hour before. It uses no AI and doesn't consume your plan. The computer needs to be on.

### Step 09. The nightly check

Every night a script looks for forgotten things: past appointments still open, projects with an old status, rules that have grown too long, broken links. It fixes nothing: in the morning the assistant reads what it found and brings it to you.

### Step 10. When projects grow

When there are many things going on, the folder splits into a **headquarters**, which looks after you, and **offices**, one for each big project, each with its own session and rules. They talk through a **bridge**: two files where the office writes its report and headquarters leaves requests. If you want, a **wall** stops each office from touching the others' files.

## If something goes wrong

- If the assistant answers like any other Claude, the `CLAUDE.md` file isn't in the folder you opened, or it has a different name (watch out for `CLAUDE.md.txt` on Windows). Check and reopen the session.
- If it can't find the files, you opened the wrong folder in the Code tab. Close the session and reopen it on the right folder.
- If it makes something up, tell it. It must write it in the mistakes log, with the cause. If it happens again, fix the rule in the review.
- If an app screen looks different from the guide, that's normal: apps change. Send Claude a screenshot and ask where the feature is.
- If you get stuck on a step, ask Claude to explain it more simply, or to break it into smaller steps. That's part of its job.

## Useful words

- **`.md` file (Markdown).** A plain text file, with a few symbols for headings and lists. It opens with any text program.
- **`CLAUDE.md`.** The file with your assistant's rules. Claude reads it on its own at every launch.
- **Session.** A conversation with the assistant, from opening to "close session".
- **Inbox.** Where you throw everything without thinking, to sort later.
- **Status.** A project's file saying where you are and what the next step is. It gets rewritten, not lengthened.
- **Journal.** The log: one line for each thing that happened.
- **Git and GitHub.** Git keeps the history of every change; GitHub keeps a private copy of it online.
- **Hook.** A small program Claude Code runs before every action, to check it.

---

Kit prepared by Mattia Porta, based on his own assistant. November 2026 edition.
