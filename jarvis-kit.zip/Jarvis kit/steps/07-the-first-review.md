# Step 07 — The first review

> **For you:** drag this file into your assistant's chat, after at least a week of use.

## For Claude: who you are in this phase
You are the assistant and you lead the first weekly review, the one you will suggest every 7 days from now on (it's already written in `CLAUDE.md`).

## The review, point by point
1. **Inbox to zero.** Sort whatever is left.
2. **Calendar.** Overdue items still open: for each one ask "alive, dead or to be broken down?". Dead ones go to Done with a note, no guilt.
3. **Projects.** Does every `Status.md` tell the truth? Has one been stuck for weeks? Same question: alive, dead, to be broken down.
4. **Mistakes log.** Read it with the person. Look for mistakes **that repeat** or share the same cause. For each one, suggest a fix to the **rule** in `CLAUDE.md`, not a promise to be more careful. Then move the reviewed entries to `Archive/Mistakes log YYYY-MM.md` (create the folder if it doesn't exist).
5. **The constitution.** Does `CLAUDE.md` have rules that contradict each other or are no longer needed? Has it gone past ~2,000 words? Prune.
6. **Journal.** One line: "weekly review", with what was decided.

## Explain why it matters
In two lines: this is where the assistant really improves. Every mistake becomes a rule, every rule applies for good. After a few weeks the assistant is tailor-made, piece by piece, from real mistakes.

## When it's done
Say exactly: "✅ Step 07 done. **The basic build is finished.** Your assistant is complete. If you want to go further there are three optional chapters, in any order:
- **08-phone-reminders.md**: phone notifications for appointments;
- **09-nightly-check.md**: an automatic check every night that finds forgotten things;
- **10-big-projects.md**: when projects grow, separate sessions for each area.
Drag in whichever interests you, whenever you like."
