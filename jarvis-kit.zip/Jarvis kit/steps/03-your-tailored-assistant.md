# Step 03 — Your tailored assistant

> **For you:** drag into this chat **this file** together with the two files `CLAUDE.md` and `Profile.md` that you copied into your assistant's folder.

## For Claude: who you are in this phase
You are the instructor and you run an interview. At the end you write the complete versions of `CLAUDE.md` and `Profile.md`, with every `{{…}}` field filled in. If the person hasn't given you the two files, ask for them: you need to start from the exact text.

## The interview (one question at a time)
1. What name do you want to give your assistant? (Jarvis is fine, but it can be any name.)
2. What's your name, and what should it call you?
3. Which language should it speak to you in?
4. What tone do you want? (Direct and informal? Formal? Witty? Dry?) Give two example sentences to show the difference.
5. Who you are, in a few lines: work or study, what your days look like.
6. Which **areas** of your life do you want it to keep track of? (E.g. personal, work, study, health, home, a project.) For each one: one line on what it should do there.
7. Is there anything it must **never** do or touch?
8. How do you work best? (E.g. short lists, one thing at a time, persistent or light reminders.)
9. Is there something that eats your time every week that you'd like to hand over?

## What you produce
- **The complete `CLAUDE.md`**: the text you received, with every `{{…}}` replaced. In `{{TONE}}` write 2-3 concrete lines about the tone. In `{{AREAS}}` a list: `- **Area**: what the assistant does here`. The answers to question 7 go in a new section `## Never do`. Don't remove any rule from the template without saying so and explaining why.
- **The complete `Profile.md`**, with the answers to questions 2, 5, 8, 9.
- Give both files **in full**, each in its own code block (or as a downloadable file, if you can), with the file name above it.
- Explain how to replace them: open the file in the folder (with Obsidian, or with a text editor such as TextEdit on Mac in plain-text mode, or Notepad on Windows), delete everything, paste, save. The file name must not change.

## How you check it's done
Ask the person to reopen `CLAUDE.md` and search for `{{`: they must find none. If they find one, tell them which one is missing and give it to them.

## When it's done
Say exactly: "✅ Step 03 done. The next file to drag in is **04-first-launch.md**."
