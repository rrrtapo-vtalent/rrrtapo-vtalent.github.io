# Step 08 (optional) — Phone reminders

> **For you:** drag this file into your assistant's chat.

## For Claude: who you are in this phase
You are the assistant and you build with the person a notification system **that runs without AI**: a small script the computer launches at set times, which reads `Calendar.md` and sends an alert to the phone. No cost, no use of the Claude plan.

## How it works (explain it in three lines)
- **ntfy** is a free notification service: you install the app on your phone, subscribe to a "topic" with a secret name, and any message sent to that topic reaches you as a notification.
- A script reads the calendar: for every appointment with a time (`due: YYYY-MM-DD HH:MM`) it sends an alert the day before and about an hour before, and marks in the line that the alert has gone out, so it doesn't repeat it.
- The computer launches the script every few minutes (on Mac with **launchd**, on Windows with **Task Scheduler**). The computer must be on.

## What must happen
1. The person installs the **ntfy** app on their phone (App Store or Google Play) and subscribes to a topic with a long, random name (you suggest it: anyone who knows the name can read the notifications).
2. **The topic name is a secret**: it goes in a separate file (e.g. `local_config.py` or `.env`), **added to `.gitignore`**, never in `CLAUDE.md` or in any other file saved to GitHub.
3. Write the script (Python is fine; check it's installed), with:
   - reading the lines of `Calendar.md` that have `due` and a time;
   - sending with an HTTP request to `https://ntfy.sh/<topic>`;
   - marking the line (e.g. `| alerted: 24h,1h`) so the same alert is never sent twice;
   - a log file with what it sent and any errors.
4. **Real test:** send a test message and ask the person whether it reached their phone. Then put a fake appointment in the calendar 70 minutes from now and wait for the one-hour alert. **If it doesn't arrive, the system doesn't work**, even if the script shows no errors.
5. Schedule the script in the operating system and check it starts on its own (look at the log after a few minutes).
6. Write a short "Reminders" section in `CLAUDE.md`: how it works, where the script, log and secret are, and the rule "when you add an appointment with a time, send a confirmation push right away".

## When it's done
Say exactly: "✅ Step 08 done. If you like, the other optional chapters are **09-nightly-check.md** and **10-big-projects.md**."
