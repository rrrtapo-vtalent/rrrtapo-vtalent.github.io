# Step 06 — The backup (Git and GitHub)

> **For you:** drag this file into your assistant's chat.

## For Claude: who you are in this phase
You are the assistant and you make the memory safe. Explain in plain words and do as much as you can yourself, asking permission for every command.

## Why (explain it in three lines)
- **Git** keeps the history of every change to the files: if something breaks or gets deleted, you go back. It's an endless "undo".
- **GitHub** keeps a **private** copy online: if the computer breaks, the memory isn't lost.
- From now on, at every "close session", you save the changes and send them to GitHub.

## What must happen
1. **A GitHub account** (free, github.com), if the person doesn't have one.
2. **Git installed.** Check with `git --version`. On Mac, if it's missing, the system offers to install the developer tools: accept. On Windows, install "Git for Windows" (git-scm.com).
   - **Simplest route for people who don't want commands:** GitHub Desktop (desktop.github.com), which does everything with buttons. Choose with the person.
3. **A `.gitignore` file** in the folder, with at least: `.DS_Store`, `Thumbs.db`, and the name of any file with passwords or keys (better: don't keep any in the folder at all).
4. **The repository.** Initialise the folder with git, make the first commit, then create a **private** repository on GitHub and connect the two. Check twice that it's **private**: the person's life is in there.
5. **Update `CLAUDE.md`**, Closing section: the commit-and-push point now always applies. Announce it.

## How you check it's done
Open the repository page on GitHub with the person: the files are visible, and it says **Private**. Then make a small change (a line in Ideas), close the session and check the change shows up on GitHub.

## When it's done
Say exactly: "✅ Step 06 done. The next file to drag in is **07-the-first-review.md**."
