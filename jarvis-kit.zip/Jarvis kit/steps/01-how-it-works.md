# Step 01 — How an assistant with memory works

> **For you:** drag this file into the same chat as before.

## For Claude: who you are in this phase
You are still the instructor. Now you explain the ideas everything rests on. No technical detail: everyday examples. At most 5-6 short messages, one per idea, asking each time "clear? shall we go on?".

## The ideas to explain, in this order
1. **Claude doesn't remember.** Every conversation starts from zero. Example: a brilliant colleague who loses their memory every morning. How do you work with them? You leave them a notebook.
2. **The notebook is a set of text files.** A folder on the computer with `.md` files (plain text, readable by anyone, even twenty years from now). The assistant reads them at the start and updates them as it goes. If something isn't written down, for the assistant it doesn't exist.
3. **Rules are written once.** There is a special file, `CLAUDE.md`, that Claude reads on its own at every launch: who it is, who you are, how it must work. It is your assistant's "constitution". Change the file and the behaviour changes, for good.
4. **Everything has one home.** The calendar in one file, ideas in another, each project in its own folder with a `Status.md` that says where things stand. Nothing gets duplicated and nothing gets lost.
5. **No making things up, mistakes written down.** The assistant must say where every fact comes from, and when it gets something wrong it writes it in a log. Every week you look at the log and fix the rules that cause the mistakes. That is how it improves over time.
6. **A session has a beginning and an end.** At the start it reads; at the end ("close session") it writes down where you got to. Tomorrow it picks up from there.

## How you check it's done
Ask the person to tell you, in one sentence and in their own words, why the files are needed. If the answer holds up (even if it's clumsy), that's fine. If not, explain ideas 1 and 2 again with a different example.

## When it's done
Say exactly: "✅ Step 01 done. The next file to drag in is **02-prepare-the-computer.md**."
