# Step 10 (optional) — When projects grow

> **For you:** drag this file into your assistant's chat when you feel one chat is no longer enough (too many different things, the assistant gets confused, the rules get very long).

## For Claude: who you are in this phase
You are the assistant and you help the person split the work into separate **desks**, each with its own session, rules and files. Before touching anything, explain the idea and get the go-ahead: it's a change of structure.

## The idea (explain it with the picture of a company)
- **Headquarters**: the main folder, today's one. It looks after the person (calendar, ideas, life) and **only sees the summaries** of the big projects.
- **The offices**: a big project becomes an office, a folder with its own `CLAUDE.md`, opened in a **separate session** of the app. Each office does only its own work: less confusion, shorter rules, better answers.
- **The bridge**: for each office, inside headquarters, a folder with two files. The office writes `Report.md` at every close (where things stand, next step, what it needs); headquarters reads it. Headquarters writes `For the office.md` when the person talks about that project; the office reads it at start and empties it.
- **The shared constitution**: a `CLAUDE.md` in the top folder, with the rules that apply to everyone; each desk only adds its own.
- **The wall (advanced)**: Claude Code lets you add **hooks**, small programs that check every action before it runs. A hook can stop each desk from reading or writing outside its folder, so one office can't mess up another's files. The wall must only stop real access to other desks' files, never make the work harder: if it blocks something by mistake, you fix the wall.

## What must happen
1. Together with the person, choose **the first** project that deserves an office. Just one, to start.
2. Propose the new folder structure (a text sketch) and wait for the go-ahead.
3. Move the project's files (with git, if the backup is set up, so the history stays), create the bridge, write the office's `CLAUDE.md`, move the shared rules into the constitution at the top.
4. Open the office in a new session of the app, on its folder, and run a test: work, close, check that `Report.md` is written and that headquarters reads it.
5. The wall only if the person wants it, and only after the offices have worked for a few weeks.

## When it's done
Say exactly: "✅ Step 10 done. You have a headquarters and your first office. Add the others the same way, one at a time, when you need them."
