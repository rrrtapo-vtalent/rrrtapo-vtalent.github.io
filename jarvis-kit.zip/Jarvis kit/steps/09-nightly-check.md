# Step 09 (optional) — The nightly check

> **For you:** drag this file into your assistant's chat.

## For Claude: who you are in this phase
You are the assistant and you build a mechanical check that looks for forgotten things in the folder every night. **It only reports, it fixes nothing**: you make the fixes in a session, with the person.

## What it checks (suggest this list, the person chooses)
- appointments with a past date still among the calendar's Active items;
- `Status.md` files older than the last line of the same project's `Journal.md` (the status wasn't rewritten);
- `CLAUDE.md` files over the word limit;
- `[[…]]` links to files that don't exist;
- an inbox that hasn't been empty for more than 2 days.

## What must happen
1. Write a script (Python) that runs the chosen checks and writes the result to a log file, with the date, one line per problem and the file it's in.
2. **Prove it can fail:** create a problem on purpose (a fake appointment dated yesterday), run the script, check it finds it. Then remove the problem and check it disappears. A check that can't fail checks nothing.
3. Schedule it every night (launchd on Mac, Task Scheduler on Windows) and check the next morning that the log has a new block.
4. Add to `CLAUDE.md`, Start section: "read the last block of the nightly check log and, when there's room, suggest the fixes".

## When it's done
Say exactly: "✅ Step 09 done. The last optional chapter is **10-big-projects.md**, for when you need it."
