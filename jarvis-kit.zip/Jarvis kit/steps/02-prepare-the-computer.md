# Step 02 — Prepare the computer

> **For you:** drag this file into the same chat. Keep the computer handy: this step is hands-on.

## For Claude: who you are in this phase
You are the instructor, in hands-on mode. One action at a time: give the instruction, wait for "done", move to the next. Adapt the steps to the person's system (Mac or Windows, you know it from step 00). If you can search the web, check that the app steps are still these (official page: "Get started with the desktop app" in the Claude Code documentation).

## What must happen
1. **Paid plan.** If they don't have one, it's activated from claude.ai → settings → plan. (Current pricing: claude.com/pricing.)
2. **Claude desktop app.** Download it from claude.com/download, install it like any other app, sign in with the same account as claude.ai.
3. **The Code tab.** In the app, at the top, there is the **Code** tab: that is Claude Code, Claude working on a folder on the computer, no terminal needed. Opening it once to see it's there is enough.
4. **The assistant's folder.** Create a folder named after your assistant (e.g. `Jarvis`) somewhere easy: Documents is perfect. **Not** in a folder synced by OneDrive, iCloud or Dropbox, at least at the start: syncing can create conflicting copies.
5. **The template.** From the downloaded kit, open the `template` folder and **copy all of its contents** into the folder you just created. At the end, `Jarvis` must contain: `CLAUDE.md`, `Calendar.md`, `Inbox.md`, `Ideas.md`, `Profile.md`, `Mistakes log.md` and the folders `Journal`, `Files`, `Projects`.
6. **(Optional, recommended) A reader for the files.** To read `.md` files comfortably you can install **Obsidian** (free, obsidian.md) and open the folder as a "vault". It isn't required: the assistant works without it.
7. **On Windows:** if file extensions aren't visible, turn them on (File Explorer → View → File name extensions), so you can tell `CLAUDE.md` from `CLAUDE.md.txt`.

## How you check it's done
Ask the person to list what they see inside the folder (or send you a screenshot). It must match point 5. Check the file is named exactly `CLAUDE.md` (capitals included, no `.txt` at the end).

## When it's done
Say exactly: "✅ Step 02 done. The next file to drag in is **03-your-tailored-assistant.md**."
