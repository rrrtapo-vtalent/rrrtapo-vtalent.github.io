# Files

*Drop documents, PDFs, spreadsheets, photos here for the assistant to read. It isn't an archive: the assistant extracts the data, writes it in the right place, then asks whether the file can be removed.*
