# Mistakes log

*Every mistake the assistant makes, as soon as it happens. It serves one purpose: finding the mistakes that repeat and fixing the rule that causes them. In the weekly review it gets read, the rules get fixed, and the reviewed entries go to an archive.*
*Format: `- YYYY-MM-DD, **what happened**, real cause, how it's fixed`*
