# Calendar

*Appointments and things to do. Format: `- [ ] Description | due: YYYY-MM-DD` (with the time if it's an appointment: `YYYY-MM-DD HH:MM`). No date given, no deadline. Finished items move down to "Done"; they're never deleted.*

## Priorities for tomorrow
*(3 at most, chosen at the end of the session)*

## Active

## Done
