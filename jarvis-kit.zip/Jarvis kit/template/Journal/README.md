# Journal

*One file per month, `YYYY-MM.md`, one line for everything that happened: `| date | what | where |`. It's the log, not the status: where things stand is in the projects' `Status.md` files. The assistant creates the month's file on its own with the first line.*
