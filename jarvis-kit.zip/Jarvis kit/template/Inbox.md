# Inbox

*Everything that comes in on the fly ends up here, without thinking. At every session the assistant suggests where to put it, you confirm, the line goes. A healthy inbox is an empty inbox at the end of the day.*

## To sort
