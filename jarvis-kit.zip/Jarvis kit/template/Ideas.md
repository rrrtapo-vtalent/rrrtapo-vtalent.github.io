# Ideas

*A parking lot with no obligation: an idea can stay here for ever or die peacefully. It isn't a to-do list.*
*Format: `- **Idea**: description | status: new / parked / archived | YYYY-MM-DD`*
