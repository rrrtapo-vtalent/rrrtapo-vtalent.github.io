# CLAUDE.md — {{PROJECT_NAME}}

*This project's rules. For a new project, the assistant copies this folder, renames it and fills it in with you.*

## Goal
{{GOAL: what "done" means, in one or two lines}}

## How we work here
{{The rules decided for this project. Rewritten when they change, not appended.}}
