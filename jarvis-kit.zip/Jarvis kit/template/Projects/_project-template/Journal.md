# Journal — {{PROJECT_NAME}}

*A short log: date, what happened, link. Decisions in your words, not the assistant's guesses.*
