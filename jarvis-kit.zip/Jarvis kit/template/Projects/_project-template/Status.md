# Status — {{PROJECT_NAME}}

*Where things stand and where to pick up. Rewritten at every session close: it's the only place where the project's status lives.*

- **Where we are:**
- **Next step:**
- **What's needed from me:**
- **Updated on:**
