# Profile

*Who you are, written for your assistant. Filled in at step 03 of the guide and updated when something changes. Write only what you want it to know: no passwords, no data you don't want in a file.*

## In short
{{WHO_YOU_ARE}}

## Work or study
{{WORK}}

## What I want the assistant to do for me
{{GOALS}}

## How I work best
{{PREFERENCES}}
