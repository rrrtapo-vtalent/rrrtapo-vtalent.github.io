# Kit Jarvis — leggimi

Questo kit ti fa costruire un assistente personale con memoria, guidato passo passo da Claude.

**Per cominciare:** apri claude.ai, inizia una chat nuova e trascina dentro il file `passi/00-inizia-qui.md`. Da lì ti guida Claude, e alla fine di ogni passo ti dice quale file trascinare dopo.

Cosa c'è qui:

- `GUIDA.md` e `Guida - Costruisci il tuo Jarvis.pdf`: la guida per te, da leggere o stampare, per sapere sempre dove sei.
- `passi/`: le istruzioni per Claude, da `00` a `10`. Non serve leggerle: si trascinano nella chat, una alla volta.
- `modello/`: lo scheletro della cartella del tuo assistente. Al passo 02 ne copi il contenuto in una cartella tua.

Ti serve un computer (Mac o Windows) e un piano a pagamento di Claude, da Pro in su, per la scheda Code dell'app desktop.

Kit preparato da Mattia Porta. Edizione novembre 2026.
