# Costruisci il tuo Jarvis

Un assistente personale che si ricorda di te, delle tue cose e di come vuoi lavorare. Questa guida ti porta dall'inizio alla fine anche se non hai mai scritto una riga di codice: il lavoro tecnico lo fa Claude, tu segui i passi e prendi le decisioni.

## Cosa stai per costruire

Claude, da solo, dimentica tutto alla fine di ogni conversazione. Il tuo Jarvis no, perché tiene la memoria in una cartella sul tuo computer: file di testo semplice che legge all'inizio di ogni sessione e aggiorna mentre lavorate. Dentro ci sono le sue regole, la tua agenda, le tue idee, lo stato di ogni progetto, un diario di ciò che succede e un registro dei suoi errori.

Alla fine avrai:

- un assistente con il nome, la lingua e il tono che scegli tu;
- un'agenda e una "inbox" dove scaricare tutto ciò che hai in testa;
- una cartella per ogni progetto, che dice sempre dove sei arrivato e qual è il prossimo passo;
- un backup privato su GitHub con la storia di ogni modifica;
- se vuoi, promemoria sul telefono e un controllo automatico ogni notte.

## Cosa ti serve

- Un computer, Mac o Windows.
- Un account Claude con un piano a pagamento, da Pro in su: il tuo Jarvis vive nella scheda Code dell'app desktop di Claude, compresa nei piani a pagamento. Il prezzo aggiornato è su claude.com/pricing. Con il piano gratuito puoi fare la prima parte della guida, non la seconda.
- Un'ora o due per la costruzione, poi una settimana d'uso quotidiano, anche cinque minuti al giorno.

## Come funziona questo kit

- Nella cartella `passi/` ci sono undici file numerati, da `00` a `10`. Ognuno contiene le istruzioni per Claude su un passo della costruzione. **Non devi leggerli tu**: li trascini nella chat, uno alla volta, e Claude sa cosa fare. Alla fine di ogni passo è lui a dirti qual è il prossimo file.
- In `modello/` c'è lo scheletro della cartella del tuo assistente, con i file già pronti da personalizzare.
- C'è anche questa guida, da leggere o stampare, per sapere sempre dove sei.

La costruzione ha due fasi. Nella **prima** parli con Claude sul sito claude.ai, che ti fa da istruttore. Nella **seconda** parli con il tuo nuovo assistente, che finisce di costruirsi insieme a te.

## Fase 1 — Su claude.ai, con Claude come istruttore

### Passo 00. Inizia qui

Apri claude.ai, inizia una chat nuova e trascina dentro `00-inizia-qui.md`. Claude ti spiega il percorso e ti fa quattro domande: che computer usi, che piano hai, quanto sei pratico di file e cartelle, cosa vuoi che il tuo assistente faccia per te.

*Alla fine:* sai cosa ti serve e Claude conosce la tua situazione.

### Passo 01. Come funziona

Trascina `01-come-funziona.md` nella stessa chat. Claude ti spiega le sei idee su cui si regge tutto: perché Claude non ricorda, perché la memoria sta in file di testo, perché le regole si scrivono una volta sola, perché ogni cosa ha una casa sola, perché l'assistente deve citare le fonti e scrivere i suoi errori, perché ogni sessione ha un inizio e una fine.

*Alla fine:* sai spiegare con parole tue perché servono i file.

### Passo 02. Prepara il computer

Trascina `02-prepara-il-computer.md`. Qui si fanno cose, una alla volta:

1. attivi il piano a pagamento, se non ce l'hai;
2. installi l'**app desktop di Claude** da claude.com/download e accedi con il tuo account;
3. guardi la scheda **Code** dell'app: è lì che vivrà il tuo assistente;
4. crei una cartella con il suo nome, per esempio `Jarvis`, in Documenti. Meglio non in una cartella sincronizzata da OneDrive, iCloud o Dropbox;
5. copi dentro tutto il contenuto della cartella `modello` del kit;
6. se vuoi, installi **Obsidian** (gratuito) per leggere comodamente i file.

*Alla fine:* nella cartella ci sono `CLAUDE.md`, `Agenda.md`, `Inbox.md`, `Idee.md`, `Profilo.md`, `Registro errori.md` e le cartelle `Diario`, `File`, `Progetti`.

### Passo 03. Il tuo assistente su misura

Trascina `03-il-tuo-assistente-su-misura.md` **insieme** ai file `CLAUDE.md` e `Profilo.md` della tua cartella. Claude ti fa un'intervista: che nome dare all'assistente, come vuoi essere chiamato, lingua, tono, chi sei, quali aree della tua vita deve tenere, cosa non deve mai fare, come lavori meglio. Poi ti restituisce i due file completi: li apri, sostituisci tutto il testo, salvi.

*Alla fine:* in `CLAUDE.md` non c'è più nessun segnaposto tra doppie graffe `{{ }}`.

### Passo 04. Primo avvio

Trascina `04-primo-avvio.md`. Apri l'app desktop, scheda **Code**, scegli di lavorare in locale e apri la cartella del tuo assistente. Scrivi "Ciao". Poi fai cinque prove:

1. **si presenta** con il nome che hai scelto;
2. **ti conosce**: alla domanda "cosa sai di me?" risponde con il tuo profilo;
3. **non inventa**: a una domanda su qualcosa che non gli hai mai detto risponde "non lo so";
4. **scrive**: se gli chiedi di metterti una cosa in agenda, la trovi nel file;
5. **ricorda**: chiudi la sessione, ne apri una nuova, e sa ancora cosa c'è in agenda.

*Alla fine:* il tuo assistente è vivo. Da qui in poi i file li trascini nella sua chat, non più su claude.ai.

## Fase 2 — Con il tuo assistente

### Passo 05. La prima settimana

Trascina `05-la-prima-settimana.md` nella chat del tuo assistente. Ti insegna quattro abitudini, usandole su cose vere: svuotare la testa nell'inbox e smistarla; creare il primo progetto con il suo stato; chiudere la sessione; riaprirla il giorno dopo senza doverti ricordare niente. Poi per cinque-sette giorni lo usi ogni giorno, anche pochi minuti. Ogni volta che qualcosa non ti piace, glielo dici: ti propone una regola nuova, e da quel momento vale per sempre.

### Passo 06. Il backup

Trascina `06-il-backup.md`. L'assistente ti aiuta a creare un account GitHub (gratuito) e un repository **privato**, e ci collega la cartella con Git. Da quel momento ogni modifica ha una storia, si può sempre tornare indietro, e se il computer si rompe la memoria non si perde. Se preferisci i pulsanti ai comandi, puoi usare GitHub Desktop.

*Alla fine:* su GitHub vedi i tuoi file, con scritto **Private**.

### Passo 07. La prima review

Dopo almeno una settimana, trascina `07-la-prima-review.md`. È il momento in cui l'assistente migliora davvero: svuotate l'inbox, guardate cosa è scaduto in agenda e i progetti fermi ("vivo, morto o da spacchettare?"), leggete il registro dei suoi errori e, per quelli che si ripetono, correggete la regola che li causa. Da qui in poi la review te la propone lui, ogni settimana.

*Alla fine:* la costruzione di base è finita.

## Capitoli facoltativi

Quando vuoi, in qualsiasi ordine.

### Passo 08. Promemoria sul telefono

Con l'app gratuita **ntfy** e un piccolo script che il computer lancia da solo, gli appuntamenti con l'ora ti arrivano come notifica il giorno prima e un'ora prima. Non usa l'IA e non consuma il tuo piano. Serve il computer acceso.

### Passo 09. Il controllo notturno

Ogni notte uno script cerca le cose dimenticate: appuntamenti passati ancora aperti, progetti con lo stato vecchio, regole troppo lunghe, collegamenti rotti. Non corregge niente: la mattina l'assistente legge cosa ha trovato e te lo propone.

### Passo 10. Quando i progetti crescono

Quando le cose diventano tante, la cartella si divide in una **sede**, che tiene te, e degli **uffici**, uno per ogni progetto grande, ognuno con la sua sessione e le sue regole. Si parlano attraverso un **ponte**: due file in cui l'ufficio scrive il suo resoconto e la sede lascia le richieste. Se vuoi, un **muro** impedisce a ogni ufficio di toccare i file degli altri.

## Se qualcosa va storto

- Se l'assistente risponde come un Claude qualsiasi, il file `CLAUDE.md` non è nella cartella aperta, oppure si chiama in un altro modo (attento a `CLAUDE.md.txt` su Windows). Controlla e riapri la sessione.
- Se non trova i file, nella scheda Code hai aperto la cartella sbagliata. Chiudi la sessione e riaprila sulla cartella giusta.
- Se inventa una cosa, diglielo. Deve scriverla nel registro degli errori, con la causa. Se succede di nuovo, nella review correggete la regola.
- Se una schermata dell'app è diversa da come la descrive la guida, è normale: le app cambiano. Manda uno screenshot a Claude e chiedi dove si trova la funzione.
- Se ti blocchi su un passo, chiedi a Claude di spiegartelo in modo più semplice, o di spezzarlo in passi più piccoli. È parte del suo lavoro.

## Parole utili

- **File `.md` (Markdown).** Un file di testo semplice, con qualche simbolo per titoli ed elenchi. Si apre con qualsiasi programma di testo.
- **`CLAUDE.md`.** Il file con le regole del tuo assistente. Claude lo legge da solo a ogni avvio.
- **Sessione.** Una conversazione con l'assistente, dall'apertura a "chiudi sessione".
- **Inbox.** Il posto dove butti tutto senza pensarci, da smistare dopo.
- **Stato.** Il file di un progetto che dice dove sei e qual è il prossimo passo. Si riscrive, non si allunga.
- **Diario.** La cronaca: una riga per ogni cosa successa.
- **Git e GitHub.** Git tiene la storia di ogni modifica; GitHub ne tiene una copia online, privata.
- **Hook.** Un piccolo programma che Claude Code esegue prima di ogni azione, per controllarla.

---

Kit preparato da Mattia Porta, a partire dal suo assistente. Edizione novembre 2026.
