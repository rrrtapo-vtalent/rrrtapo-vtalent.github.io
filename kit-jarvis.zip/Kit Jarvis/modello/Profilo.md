# Profilo

*Chi sei, scritto per il tuo assistente. Si riempie al passo 03 della guida e si aggiorna quando cambia qualcosa. Scrivi solo ciò che vuoi che sappia: niente password, niente dati che non vuoi in un file.*

## In breve
{{CHI_SEI}}

## Lavoro o studio
{{LAVORO}}

## Cosa voglio che l'assistente faccia per me
{{OBIETTIVI}}

## Come lavoro meglio
{{PREFERENZE}}
