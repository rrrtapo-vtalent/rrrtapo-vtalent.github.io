# Agenda

*Appuntamenti e cose da fare. Formato: `- [ ] Descrizione | scadenza: AAAA-MM-GG` (con l'ora se è un appuntamento: `AAAA-MM-GG HH:MM`). Senza data detta, niente scadenza. Le cose fatte scendono in "Fatti", non si cancellano.*

## Priorità domani
*(massimo 3, si scelgono a fine sessione)*

## Attivi

## Fatti
