# Inbox

*Tutto ciò che arriva al volo finisce qui, senza pensarci. A ogni sessione l'assistente propone dove metterlo, tu confermi, la riga si toglie. Inbox sana = inbox vuota a fine giornata.*

## Da smistare
