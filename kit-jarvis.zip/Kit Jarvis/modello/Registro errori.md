# Registro errori

*Ogni errore dell'assistente, appena succede. Serve a una cosa: trovare gli errori che si ripetono e correggere la regola che li causa. Nella review settimanale si legge, si corregge, e le voci analizzate vanno in un archivio.*
*Formato: `- AAAA-MM-GG · **cosa è successo** · causa vera · come si corregge`*
