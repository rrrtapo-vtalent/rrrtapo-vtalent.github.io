# File

*Qui lasci documenti, PDF, fogli, foto da far leggere all'assistente. Non è un archivio: l'assistente ne estrae i dati, li scrive al posto giusto e poi ti chiede se il file si può togliere.*
