# Idee

*Parcheggio senza obbligo: un'idea può restare qui per sempre o morire serenamente. Non è una lista di cose da fare.*
*Formato: `- **Idea**: descrizione | stato: nuova / parcheggiata / archiviata | AAAA-MM-GG`*
