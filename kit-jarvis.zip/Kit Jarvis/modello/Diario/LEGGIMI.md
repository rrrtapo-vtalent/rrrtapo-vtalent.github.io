# Diario

*Un file al mese, `AAAA-MM.md`, una riga per ogni cosa successa: `| data | cosa | dove |`. È la cronaca, non lo stato: dove siamo lo dicono gli `Stato.md` dei progetti. L'assistente crea il file del mese da solo alla prima riga.*
