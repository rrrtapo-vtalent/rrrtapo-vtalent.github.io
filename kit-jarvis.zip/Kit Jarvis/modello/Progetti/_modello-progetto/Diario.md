# Diario — {{NOME_PROGETTO}}

*Cronaca breve: data, cosa è successo, link. Le decisioni con le parole tue, non le ipotesi dell'assistente.*
