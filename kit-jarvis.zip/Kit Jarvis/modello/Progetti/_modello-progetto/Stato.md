# Stato — {{NOME_PROGETTO}}

*Dove siamo e da dove si riparte. Si riscrive a ogni chiusura di sessione: è l'unico posto dove vive lo stato del progetto.*

- **Dove siamo:**
- **Prossimo passo:**
- **Cosa serve da me:**
- **Aggiornato il:**
