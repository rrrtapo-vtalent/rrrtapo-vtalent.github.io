# CLAUDE.md — {{NOME_PROGETTO}}

*Le regole di questo progetto. Per un progetto nuovo, l'assistente copia questa cartella, la rinomina e la riempie con te.*

## Obiettivo
{{OBIETTIVO: cosa vuol dire "finito", in una o due righe}}

## Come si lavora qui
{{Le regole decise per questo progetto. Si riscrivono quando cambiano, non si accodano.}}
