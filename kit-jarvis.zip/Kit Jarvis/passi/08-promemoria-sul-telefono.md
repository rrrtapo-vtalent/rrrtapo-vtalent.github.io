# Passo 08 (facoltativo) — Promemoria sul telefono

> **Per te:** trascina questo file nella chat del tuo assistente.

## Per Claude: chi sei in questa fase
Sei l'assistente e costruisci con la persona un sistema di notifiche **che gira senza l'IA**: un piccolo script lanciato dal computer a orari fissi, che legge `Agenda.md` e manda un avviso al telefono. Niente costi, niente consumo del piano Claude.

## Come funziona (spiegalo in tre righe)
- **ntfy** è un servizio gratuito di notifiche: installi l'app sul telefono, ti iscrivi a un "argomento" con un nome segreto, e qualsiasi messaggio mandato a quell'argomento ti arriva come notifica.
- Uno script legge l'agenda: per ogni appuntamento con l'ora (`scadenza: AAAA-MM-GG HH:MM`) manda un avviso il giorno prima e circa un'ora prima, e segna nella riga che l'avviso è partito, così non lo ripete.
- Il computer lancia lo script ogni pochi minuti (su Mac con **launchd**, su Windows con l'**Utilità di pianificazione**). Il computer deve essere acceso.

## Cosa deve succedere
1. La persona installa l'app **ntfy** sul telefono (App Store o Google Play) e si iscrive a un argomento con un nome lungo e casuale (proponilo tu: chi conosce il nome può leggere le notifiche).
2. **Il nome dell'argomento è un segreto**: va in un file a parte (es. `config_locale.py` o `.env`), **aggiunto al `.gitignore`**, mai nel `CLAUDE.md` né in altri file salvati su GitHub.
3. Scrivi lo script (Python va bene; controlla che sia installato), con:
   - lettura delle righe di `Agenda.md` con `scadenza` e ora;
   - invio con una richiesta HTTP a `https://ntfy.sh/<argomento>`;
   - marcatura nella riga (es. `| avvisato: 24h,1h`) per non mandare due volte lo stesso avviso;
   - un file di log con cosa ha mandato e gli errori.
4. **Prova vera:** manda un messaggio di test e chiedi alla persona se le è arrivato sul telefono. Poi metti in agenda un appuntamento finto fra 70 minuti e aspetta l'avviso di un'ora prima. **Se non arriva, il sistema non funziona**, anche se lo script non dà errori.
5. Programma lo script nel sistema operativo e verifica che parta da solo (controlla il log dopo qualche minuto).
6. Scrivi nel `CLAUDE.md` una sezione breve "Promemoria": come funziona, dove sono script, log e segreto, e la regola "quando aggiungi un appuntamento con l'ora, manda subito un push di conferma".

## Quando è finito
Di' esattamente: "✅ Passo 08 fatto. Se vuoi, gli altri capitoli facoltativi sono **09-controllo-notturno.md** e **10-progetti-grandi.md**."
