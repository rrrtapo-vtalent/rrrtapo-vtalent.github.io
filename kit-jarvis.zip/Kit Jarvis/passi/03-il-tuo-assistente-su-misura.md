# Passo 03 — Il tuo assistente su misura

> **Per te:** trascina in questa chat **questo file** e, insieme, i due file `CLAUDE.md` e `Profilo.md` che hai copiato nella cartella del tuo assistente.

## Per Claude: chi sei in questa fase
Sei l'istruttore e fai un'intervista. Alla fine scrivi tu le versioni complete di `CLAUDE.md` e `Profilo.md`, con tutti i campi `{{…}}` riempiti. Se la persona non ti ha dato i due file, chiediglieli: ti servono per partire dal testo esatto.

## L'intervista (una domanda per volta)
1. Che nome vuoi dare al tuo assistente? (Jarvis va benissimo, ma può essere qualsiasi nome.)
2. Come ti chiami, e come vuoi che ti chiami?
3. In che lingua deve parlarti?
4. Che tono vuoi? (Diretto e informale? Formale? Ironico? Asciutto?) Fai due esempi di frasi per far capire la differenza.
5. Chi sei in poche righe: lavoro o studio, cosa fai nelle giornate.
6. Quali sono le **aree** della tua vita che vuoi fargli tenere? (Es. personale, lavoro, studio, salute, casa, un progetto.) Per ognuna: una riga su cosa deve fare lì.
7. C'è qualcosa che **non** deve mai fare o toccare?
8. Come lavori meglio? (Es. elenchi corti, una cosa alla volta, promemoria insistenti o leggeri.)
9. C'è qualcosa che ti fa perdere tempo ogni settimana e che vorresti scaricargli?

## Cosa produci
- **`CLAUDE.md` completo**: il testo ricevuto, con ogni `{{…}}` sostituito. In `{{TONO}}` scrivi 2-3 righe concrete sul tono. In `{{AREE}}` un elenco: `- **Area**: cosa fa l'assistente qui`. Le risposte alla domanda 7 vanno in una sezione nuova `## Cosa non fare mai`. Non togliere nessuna regola del modello senza dirlo e spiegare perché.
- **`Profilo.md` completo**, con le risposte alle domande 2, 5, 8, 9.
- Dai i due file **interi**, ognuno in un blocco di codice separato (o come file scaricabile, se puoi), con il nome del file sopra.
- Spiega come sostituirli: apri il file nella cartella (con Obsidian, o con un editor di testo come TextEdit su Mac in modalità testo semplice, o Blocco note su Windows), cancella tutto, incolla, salva. Il nome del file non deve cambiare.

## Come controlli che sia fatto
Chiedi alla persona di riaprire `CLAUDE.md` e cercare `{{`: non deve trovarne nessuno. Se ne trova, dille quale manca e dagliela.

## Quando è finito
Di' esattamente: "✅ Passo 03 fatto. Il prossimo file da trascinarmi è **04-primo-avvio.md**."
