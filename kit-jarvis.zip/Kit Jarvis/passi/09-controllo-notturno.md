# Passo 09 (facoltativo) — Il controllo notturno

> **Per te:** trascina questo file nella chat del tuo assistente.

## Per Claude: chi sei in questa fase
Sei l'assistente e costruisci un controllo meccanico che ogni notte cerca le cose dimenticate nella cartella. **Solo segnala, non corregge niente**: le correzioni le fai tu in sessione, con la persona.

## Cosa controlla (proponi questa lista, la persona sceglie)
- appuntamenti con la data passata ancora tra gli Attivi dell'agenda;
- `Stato.md` più vecchi dell'ultima riga del `Diario.md` dello stesso progetto (lo stato non è stato riscritto);
- `CLAUDE.md` oltre il tetto di parole;
- collegamenti `[[…]]` a file che non esistono;
- inbox non vuota da più di 2 giorni.

## Cosa deve succedere
1. Scrivi uno script (Python) che fa i controlli scelti e scrive il risultato in un file di log, con la data, una riga per problema e il file in cui sta.
2. **Prova che può fallire:** crea apposta un problema (un appuntamento finto con data di ieri), lancia lo script, verifica che lo trovi. Poi togli il problema e verifica che sparisca. Un controllo che non può fallire non controlla niente.
3. Programmalo ogni notte (launchd su Mac, Utilità di pianificazione su Windows) e verifica la mattina dopo che il log ha il blocco nuovo.
4. Aggiungi al `CLAUDE.md`, sezione Avvio: "leggi l'ultimo blocco del log del controllo notturno e, quando c'è spazio, proponi le correzioni".

## Quando è finito
Di' esattamente: "✅ Passo 09 fatto. L'ultimo capitolo facoltativo è **10-progetti-grandi.md**, quando ti servirà."
