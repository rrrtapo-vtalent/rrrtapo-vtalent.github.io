# Passo 10 (facoltativo) — Quando i progetti crescono

> **Per te:** trascina questo file nella chat del tuo assistente quando senti che una sola chat non basta più (troppe cose diverse, l'assistente si confonde, le regole diventano lunghissime).

## Per Claude: chi sei in questa fase
Sei l'assistente e aiuti la persona a dividere il lavoro in **scrivanie** separate, ognuna con la sua sessione, le sue regole e i suoi file. Prima di toccare qualcosa, spiega l'idea e fatti dare il via: è un cambio di struttura.

## L'idea (spiegala con l'immagine di un'azienda)
- **La sede**: la cartella principale, quella di oggi. Tiene la persona (agenda, idee, vita) e **vede solo i riassunti** dei progetti grandi.
- **Gli uffici**: un progetto grande diventa un ufficio, una cartella con il suo `CLAUDE.md`, aperta in una **sessione separata** dell'app. Ogni ufficio fa solo il suo lavoro: meno confusione, regole più corte, risposte migliori.
- **Il ponte**: per ogni ufficio, nella sede, una cartella con due file. `Report.md` lo scrive l'ufficio a ogni chiusura (dove siamo, prossimo passo, cosa serve); la sede lo legge. `Per l'ufficio.md` lo scrive la sede quando la persona parla di quel progetto; l'ufficio lo legge all'avvio e lo svuota.
- **La costituzione comune**: un `CLAUDE.md` nella cartella più alta, con le regole che valgono per tutti; ogni scrivania aggiunge solo le sue.
- **Il muro (avanzato)**: Claude Code permette di aggiungere degli **hook**, piccoli programmi che controllano ogni azione prima che parta. Un hook può impedire a ogni scrivania di leggere o scrivere fuori dalla sua cartella. Così un ufficio non pasticcia i file di un altro. Il muro deve fermare solo l'accesso vero ai file altrui, mai rendere il lavoro più difficile: se blocca per sbaglio, si corregge il muro.

## Cosa deve succedere
1. Insieme alla persona, scegli **il primo** progetto che merita un ufficio. Uno solo, per cominciare.
2. Proponi la nuova struttura delle cartelle (un disegno a testo) e aspetta il via.
3. Sposta i file del progetto (con git, se c'è il backup, così resta la storia), crea il ponte, scrivi il `CLAUDE.md` dell'ufficio, sposta le regole comuni nella costituzione in alto.
4. Apri l'ufficio in una sessione nuova dell'app, sulla sua cartella, e fai una prova: lavorare, chiudere, verificare che il `Report.md` sia scritto e che la sede lo legga.
5. Il muro solo se la persona lo vuole, e solo dopo che gli uffici funzionano da qualche settimana.

## Quando è finito
Di' esattamente: "✅ Passo 10 fatto. Hai una sede e il tuo primo ufficio. Gli altri li aggiungi allo stesso modo, uno alla volta, quando servono."
