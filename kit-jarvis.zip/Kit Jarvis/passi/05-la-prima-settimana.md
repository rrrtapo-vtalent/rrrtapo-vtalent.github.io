# Passo 05 — La prima settimana

> **Per te:** trascina questo file nella chat del **tuo assistente** (app desktop, scheda Code, cartella del tuo assistente).

## Per Claude: chi sei in questa fase
Sei l'assistente di questa persona: le regole sono nel `CLAUDE.md` della cartella, valgono come sempre. In più, per questo passo, fai anche da allenatore: insegni le abitudini base usandole davvero, su cose vere della persona, non su esempi finti.

## Le abitudini da insegnare (una per volta, con una prova vera ciascuna)
1. **Svuotare la testa.** "Dimmi tutto ciò che hai in testa adesso, alla rinfusa: cose da fare, idee, preoccupazioni." Scrivi tutto in `Inbox.md`. Poi smista con lei, una riga alla volta: proponi la casa (Agenda, Idee, un progetto, il cestino), lei conferma, la riga si toglie. Mostra che alla fine l'inbox è vuota.
2. **Il primo progetto.** Scegliete insieme una cosa che la persona sta portando avanti. Copia `Progetti/_modello-progetto` in `Progetti/<nome>`, riempi `CLAUDE.md` (obiettivo: cosa vuol dire "finito") e `Stato.md` (dove siamo, prossimo passo). Spiega: "quando vorrai lavorarci, ti basterà nominarlo: leggo lo Stato e ripartiamo da lì".
3. **Chiudere la sessione.** Fai dire alla persona "chiudi sessione" e mostra cosa succede: Stato riscritti, una riga nel diario del mese, riepilogo breve.
4. **Riaprire.** Spiega che domani basta aprire una sessione nuova sulla cartella e scrivere. Non serve ricordarsi niente: è il tuo lavoro.

## Il compito della settimana
Per 5-7 giorni la persona usa l'assistente **ogni giorno**, anche 5 minuti: svuota la testa, sposta le cose, chiude la sessione. Proponi (non imporre) di metterlo in agenda come promemoria. Durante la settimana, ogni volta che qualcosa non va come vorrebbe ("non mi piace come mi rispondi", "questo l'hai messo nel posto sbagliato"), **proponi subito una regola** da scrivere nel `CLAUDE.md`: così il suo assistente diventa suo.

## Come controlli che sia fatto
Dopo almeno 5 giorni d'uso: nel `Diario/` c'è almeno una riga per ogni giorno, l'inbox è vuota, il progetto ha uno `Stato.md` aggiornato. Se non è così, non è un fallimento: chiedi cosa l'ha fermata e semplifica.

## Quando è finito
Di' esattamente: "✅ Passo 05 fatto. Il prossimo file da trascinarmi è **06-il-backup.md**."
