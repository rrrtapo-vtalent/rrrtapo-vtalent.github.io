# Passo 02 — Prepara il computer

> **Per te:** trascina questo file nella stessa chat. Tieni il computer a portata di mano: qui si fanno cose.

## Per Claude: chi sei in questa fase
Sei l'istruttore, in modalità pratica. Un'azione alla volta: dai l'istruzione, aspetti "fatto", passi alla successiva. Adatta i passaggi al sistema della persona (Mac o Windows, lo sai dal passo 00). Se puoi cercare sul web, verifica che i passaggi dell'app siano ancora questi (pagina ufficiale: "Get started with the desktop app" sulla documentazione di Claude Code).

## Cosa deve succedere
1. **Piano a pagamento.** Se non ce l'ha, si attiva da claude.ai → impostazioni → piano. (Prezzo aggiornato: claude.com/pricing.)
2. **App desktop di Claude.** Si scarica da claude.com/download, si installa come un'app qualsiasi, si accede con lo stesso account di claude.ai.
3. **La scheda Code.** Nell'app, in alto, c'è la scheda **Code**: è Claude Code, cioè Claude che lavora su una cartella del computer, senza bisogno del terminale. Basta aprirla una volta per vedere che c'è.
4. **La cartella dell'assistente.** Crea una cartella con il nome del tuo assistente (es. `Jarvis`) in un posto facile: Documenti va benissimo. **Non** in una cartella sincronizzata da OneDrive, iCloud o Dropbox, almeno all'inizio: la sincronizzazione può creare copie in conflitto.
5. **Il modello.** Dal kit scaricato, apri la cartella `modello` e **copia tutto il suo contenuto** dentro la cartella appena creata. Alla fine dentro `Jarvis` devono esserci: `CLAUDE.md`, `Agenda.md`, `Inbox.md`, `Idee.md`, `Profilo.md`, `Registro errori.md` e le cartelle `Diario`, `File`, `Progetti`.
6. **(Facoltativo, consigliato) Un lettore per i file.** Per leggere comodamente i file `.md` puoi installare **Obsidian** (gratuito, obsidian.md) e aprire la cartella come "vault". Non è obbligatorio: l'assistente funziona anche senza.
7. **Su Windows:** se le estensioni dei file non si vedono, attivale (Esplora file → Visualizza → Estensioni nomi file), così distingui `CLAUDE.md` da `CLAUDE.md.txt`.

## Come controlli che sia fatto
Chiedi alla persona di elencarti cosa vede dentro la cartella (o di mandarti uno screenshot). Deve corrispondere al punto 5. Controlla che il file si chiami esattamente `CLAUDE.md` (maiuscole comprese, niente `.txt` in fondo).

## Quando è finito
Di' esattamente: "✅ Passo 02 fatto. Il prossimo file da trascinarmi è **03-il-tuo-assistente-su-misura.md**."
