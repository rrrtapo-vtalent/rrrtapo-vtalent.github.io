# Passo 07 — La prima review

> **Per te:** trascina questo file nella chat del tuo assistente, dopo almeno una settimana d'uso.

## Per Claude: chi sei in questa fase
Sei l'assistente e guidi la prima review settimanale, quella che d'ora in poi proporrai tu ogni 7 giorni (è già scritto nel `CLAUDE.md`).

## La review, punto per punto
1. **Inbox a zero.** Smista quello che è rimasto.
2. **Agenda.** Cose scadute ancora aperte: per ognuna chiedi "viva, morta o da spacchettare?". Le morte vanno nei Fatti con una nota, senza sensi di colpa.
3. **Progetti.** Ogni `Stato.md` dice la verità? Ce n'è uno fermo da settimane? Stessa domanda: viva, morta, da spacchettare.
4. **Registro errori.** Leggilo con la persona. Cerca gli errori **che si ripetono** o che hanno la stessa causa. Per ognuno proponi una correzione della **regola** nel `CLAUDE.md`, non una promessa di stare più attento. Poi sposta le voci analizzate in `Archivio/Registro errori AAAA-MM.md` (crea la cartella se non c'è).
5. **La costituzione.** Il `CLAUDE.md` ha regole che si contraddicono o che non servono più? Ha superato ~2.000 parole? Pota.
6. **Diario.** Una riga: "review settimanale", con cosa si è deciso.

## Spiega perché conta
In due righe: è qui che l'assistente migliora davvero. Ogni errore diventa una regola, ogni regola vale per sempre. Dopo qualche settimana l'assistente è costruito su misura, pezzo per pezzo, dagli errori veri.

## Quando è finito
Di' esattamente: "✅ Passo 07 fatto. **La costruzione di base è finita.** Il tuo assistente è completo. Se vuoi andare oltre ci sono tre capitoli facoltativi, in qualsiasi ordine:
- **08-promemoria-sul-telefono.md**: notifiche sul telefono per gli appuntamenti;
- **09-controllo-notturno.md**: un controllo automatico ogni notte che trova cose dimenticate;
- **10-progetti-grandi.md**: quando i progetti crescono, sessioni separate per area.
Trascinami quello che ti interessa, quando vuoi."
