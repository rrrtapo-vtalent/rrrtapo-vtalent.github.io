# Passo 06 — Il backup (Git e GitHub)

> **Per te:** trascina questo file nella chat del tuo assistente.

## Per Claude: chi sei in questa fase
Sei l'assistente e metti in sicurezza la memoria. Spiega in parole semplici e fai tu il più possibile, chiedendo il permesso per ogni comando.

## Perché (spiegalo in tre righe)
- **Git** tiene la storia di ogni modifica ai file: se qualcosa si rompe o si cancella, si torna indietro. È un "annulla" infinito.
- **GitHub** tiene una copia online, **privata**: se il computer si rompe, la memoria non si perde.
- Da qui in poi, a ogni "chiudi sessione", salvi tu le modifiche e le mandi su GitHub.

## Cosa deve succedere
1. **Account GitHub** (gratuito, github.com), se la persona non ce l'ha.
2. **Git installato.** Controlla con `git --version`. Su Mac, se manca, il sistema propone di installare gli strumenti per sviluppatori: si accetta. Su Windows si installa "Git for Windows" (git-scm.com).
   - **Strada più semplice per chi non vuole comandi:** GitHub Desktop (desktop.github.com), che fa tutto con i pulsanti. Scegli con la persona.
3. **Un file `.gitignore`** nella cartella, con almeno: `.DS_Store`, `Thumbs.db`, e il nome di qualsiasi file con password o chiavi (meglio: non tenerne proprio nella cartella).
4. **Il repository.** Inizializza la cartella con git, primo commit, poi crea su GitHub un repository **privato** e collega i due. Controlla due volte che sia **privato**: dentro c'è la vita della persona.
5. **Aggiorna il `CLAUDE.md`**, sezione Chiusura: il punto del commit e del push ora vale sempre. Annuncialo.

## Come controlli che sia fatto
Apri con la persona la pagina del repository su GitHub: si vedono i file, c'è scritto **Private**. Poi fai una modifica piccola (una riga in Idee), chiudi la sessione e verifica che la modifica compaia su GitHub.

## Quando è finito
Di' esattamente: "✅ Passo 06 fatto. Il prossimo file da trascinarmi è **07-la-prima-review.md**."
