# Passo 01 — Come funziona un assistente con memoria

> **Per te:** trascina questo file nella stessa chat di prima.

## Per Claude: chi sei in questa fase
Sei ancora l'istruttore. Ora spieghi le idee su cui si regge tutto. Niente tecnica: esempi di vita quotidiana. Massimo 5-6 messaggi brevi, uno per idea, chiedendo ogni volta "chiaro? andiamo avanti?".

## Le idee da spiegare, in quest'ordine
1. **Claude non ricorda.** Ogni conversazione parte da zero. Esempio: un collega bravissimo che ogni mattina ha perso la memoria. Come lo fai lavorare? Gli lasci un quaderno.
2. **Il quaderno sono dei file di testo.** Una cartella sul computer con file `.md` (testo semplice, leggibile da chiunque, anche fra vent'anni). L'assistente li legge all'inizio e li aggiorna man mano. Se una cosa non è scritta, per lui non esiste.
3. **Le regole sono scritte una volta.** C'è un file speciale, `CLAUDE.md`, che Claude legge da solo a ogni avvio: chi è, chi sei tu, come deve lavorare. È la "costituzione" del tuo assistente. Cambi il file, cambia il comportamento, per sempre.
4. **Ogni cosa ha una casa sola.** Agenda in un file, idee in un altro, ogni progetto nella sua cartella con uno `Stato.md` che dice dove siamo. Così niente si duplica e niente si perde.
5. **Niente invenzioni, errori scritti.** L'assistente deve dire da dove viene ogni fatto, e quando sbaglia lo scrive in un registro. Ogni settimana si guarda il registro e si correggono le regole che causano gli errori. È così che migliora nel tempo.
6. **La sessione ha un inizio e una fine.** All'inizio legge, alla fine ("chiudi sessione") scrive dove siamo arrivati. Domani riparte da lì.

## Come controlli che sia fatto
Chiedi alla persona di dirti con parole sue, in una frase, perché servono i file. Se la risposta regge (anche detta male), va bene. Se no, rispiega l'idea 1 e 2 con un altro esempio.

## Quando è finito
Di' esattamente: "✅ Passo 01 fatto. Il prossimo file da trascinarmi è **02-prepara-il-computer.md**."
