# Passo 04 — Primo avvio

> **Per te:** trascina questo file nella stessa chat. È l'ultimo passo su claude.ai: alla fine il tuo assistente sarà vivo.

## Per Claude: chi sei in questa fase
Sei l'istruttore che accompagna il primo avvio e lo collauda. Dopo questo passo passi il testimone: i file successivi la persona li darà al suo nuovo assistente, non a te.

## Cosa deve succedere
1. Apri l'**app desktop di Claude** → scheda **Code**.
2. Scegli l'ambiente **locale** (Local) e, con il pulsante della cartella accanto, **Open folder** → la cartella del tuo assistente. (Se l'app è diversa da così, cerca la funzione per aprire una cartella sul computer; nel dubbio, manda uno screenshot.)
3. **Permessi.** L'app chiede il permesso prima di modificare file o lanciare comandi. All'inizio lascia che chieda sempre: leggi cosa vuole fare e approva. Quando ti fiderai, potrai allentare.
4. Scrivi: `Ciao`.

## Il collaudo (fallo fare nella scheda Code, una prova alla volta)
1. **Si presenta?** Deve salutare in breve, con il nome scelto, e chiedere su cosa lavorare. Se risponde come un Claude generico, il file `CLAUDE.md` non è nella cartella giusta o ha un nome sbagliato: torna al passo 02, punto 5.
2. **Ti conosce?** Chiedi: "Cosa sai di me?". Deve rispondere con ciò che c'è in `Profilo.md`, citando il file.
3. **Non inventa?** Chiedi una cosa che non gli hai mai detto, es. "Che macchina ho?". La risposta giusta è "non lo so, non è scritto": se inventa, il collaudo non è passato. Fai aggiungere all'assistente stesso una riga in `Registro errori.md` e ripeti la domanda.
4. **Scrive?** Di': "Mettimi in agenda: chiamare il dentista, senza data". Poi apri `Agenda.md`: la riga deve esserci, senza scadenza inventata.
5. **Ricorda?** Chiudi la sessione con "chiudi sessione", aprine una nuova sulla stessa cartella, chiedi: "Cosa c'è in agenda?". Deve dirti del dentista.

## Come controlli che sia fatto
La persona ti dice com'è andata ognuna delle 5 prove. Se una non passa, aiutala a capire perché prima di andare avanti.

## Quando è finito
Di' esattamente: "✅ Passo 04 fatto. Il tuo assistente è vivo. **Da qui in poi i file li trascini nella chat del tuo assistente** (scheda Code), non più qui. Il prossimo è **05-la-prima-settimana.md**."
